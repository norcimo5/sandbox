#!/usr/bin/expect -f
# set Variables
# grab the password
stty -echo
send_user -- "Password: "
expect_user -re "(.*)\n"
send_user "\n"
stty echo
set password $expect_out(1,string)
######
set timeout -1
spawn svn checkout svn+ssh://source/svn/ticom-geo/branches/4.0-tng /build/4.0-tng
match_max 100000
expect "*password:*" {
    send "$password\r"
    exp_continue
}
# [ DONE ]
