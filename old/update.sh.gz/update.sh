#!/usr/bin/expect -f
# set Variables
set found 0
# grab the password
stty -echo
send_user -- "Password: "
expect_user -re "(.*)\n"
send_user "\n"
stty echo
set password $expect_out(1,string)
#set ipaddr [lrange $argv 1 1]
#set scriptname [lrange $argv 2 2]
#set arg1 [lrange $argv 3 3]
set timeout -1
spawn svn update /build/4.0-tng
match_max 100000
expect "*password:*" {
    send "$password\r"
    exp_continue
}
# [ DONE ]
